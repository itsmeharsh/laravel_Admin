<?php

use Illuminate\Database\Seeder;

class roleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles = array(
        	[
        		'section_id'=>'Dashboard',
        		'title'=>'Dashboard',
        		'route'=>'admin.dashboard.index',
        		'image'=>'icon-diamond',
        		'sequence'=>1,
        		'active'=>1,
        		'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now()
        	],
            [
                'section_id'=>'General',
                'title'=>'Settings',
                'route'=>'admin.settings.index',
                'image'=>'icon-diamond',
                'sequence'=>1,
                'active'=>1,
                'created_at' => \Carbon\Carbon::now(),
                'updated_at' => \Carbon\Carbon::now()
            ],
        	[
        		'section_id'=>'Manage',
        		'title'=>'Drivers',
        		'route'=>'drivers.index',
        		'image'=>'icon-diamond',
        		'sequence'=>1,
        		'active'=>1,
        		'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now()
        	],
            [
                'section_id'=>'Manage',
                'title'=>'Mechanics',
                'route'=>'mechanics.index',
                'image'=>'icon-diamond',
                'sequence'=>2,
                'active'=>1,
                'created_at' => \Carbon\Carbon::now(),
                'updated_at' => \Carbon\Carbon::now()
            ],
            [
                'section_id'=>'Manage',
                'title'=>'Contractors',
                'route'=>'contractors.index',
                'image'=>'icon-diamond',
                'sequence'=>3,
                'active'=>1,
                'created_at' => \Carbon\Carbon::now(),
                'updated_at' => \Carbon\Carbon::now()
            ]
        );

        foreach($roles as $role){
        	$section_id = DB::table('sections')
        	->where('name', '=', $role['section_id'])
        	->first()->id;

        	$role['section_id'] = ($section_id >0 ? $section_id : 1);

        	DB::table('roles')->insert($role);
        }
    }
}
