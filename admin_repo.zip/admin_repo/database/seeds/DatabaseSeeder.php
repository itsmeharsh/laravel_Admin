<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(permissionsTableSeeder::class);
        $this->call(sectionTableSeeder::class);
        $this->call(roleTableSeeder::class);
    }
}
