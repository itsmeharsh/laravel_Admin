<?php

use Illuminate\Database\Seeder;

class permissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
        	[
				'name' => 'Access',
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
        	[
				'name' => 'View',
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
			[
				'name' => 'Add',
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
			[
				'name' => 'Edit',
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
			[
				'name' => 'Delete',
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			]
        ];
        foreach($permissions as $permission){
	        DB::table('permissions')->insert($permission);
		}
    }
}
