<?php

use Illuminate\Database\Seeder;

class sectionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sections = [
        	[
				'name' => 'Dashboard',
				'image' => 'icon-diamond',
				'sequence' => 1,
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
			[
				'name' => 'General',
				'image' => 'icon-diamond',
				'sequence' => 2,
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			],
			[
				'name' => 'Manage',
				'image' => 'icon-diamond',
				'sequence' => 3,
				'active' => 1,
				'created_at' => \Carbon\Carbon::now(),
				'updated_at' => \Carbon\Carbon::now(),
			]
        ];
        foreach($sections as $section){
	        DB::table('sections')->insert($section);
		}
    }
}
