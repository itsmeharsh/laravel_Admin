<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableLicenceImages extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('licence_images', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('licence_id')->unsigned();
            $table->string('image');
            $table->timestamps();

            $table->foreign('licence_id')->references('id')->on('licences')->onDelete('cascade')
            ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('licence_images');
    }
}
