@extends('layouts.app')
@section('content')
 <div class="row ">
    <div class="col-md-12">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-user font-green"></i>
                    <span class="caption-subject font-green bold uppercase">Add Driver</span>
                </div>
            </div>
            <div class="portlet-body">
                <form class="form-horizontal" id="frmChange" role="form" method="POST" action="{{ route('drivers.store') }}">
                    {{ csrf_field() }}
                    <h4>Personal Details</h4>
                    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                        <label for="name" class="col-md-2 control-label">{!! $mend_sign !!}Full Name</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-user"></i>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Name"> 
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                        <label for="name" class="col-md-2 control-label">{!! $mend_sign !!}Address</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-map-pin"></i>
                                <textarea name="address" id="address" class="form-control" placeholder="Address"></textarea>
                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="form-group{{ $errors->has('contact_number') ? ' has-error' : '' }}">
                        <label for="contact_number" class="col-md-2 control-label">{!! $mend_sign !!}Contact Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-phone"></i>
                                <input type="text" class="form-control" name="contact_number" id="contact_number" placeholder="Contact number"> 
                                @if ($errors->has('contact_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('contact_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                        <label for="email" class="col-md-2 control-label">{!! $mend_sign !!}E-mail address</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-envelope"></i>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Email address"> 
                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="form-group{{ $errors->has('dob') ? ' has-error' : '' }}">
                        <label for="dob" class="col-md-2 control-label">{!! $mend_sign !!}Date of birth</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control" name="dob" id="dob" placeholder="Date of birth" readonly="readonly"> 
                                @if ($errors->has('dob'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('dob') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Emergency Contact</h4>
                    <div class="form-group">
                        <label for="sos[0][name]" class="col-md-2 control-label">Name</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-user"></i>
                                <input type="text" class="form-control" name="sos[0][name]" id="sos[0][name]" placeholder="Name"> 
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="sos[0][contact_number]" class="col-md-2 control-label">Contact Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-phone"></i>
                                <input type="text" class="form-control" name="sos[0][contact_number]" id="sos[0][contact_number]" placeholder="Contact Number"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="sos[0][relation]" class="col-md-2 control-label">Relation</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-sitemap"></i>
                                <input type="text" class="form-control" name="sos[0][relation]" id="sos[0][relation]" placeholder="Relation"> 
                                
                            </div>
                        </div>
                    </div>  
                    <hr>
                    <h4>License</h4>
                    <div class="form-group">
                        <label for="licences[0][type]" class="col-md-2 control-label">Licence type</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-cubes"></i>
                                <input type="text" class="form-control" name="licences[0][type]" id="licences[0][type]" placeholder="Licence Type"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[0][number]" class="col-md-2 control-label">Licence Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-credit-card"></i>
                                <input type="text" class="form-control" name="licences[0][number]" id="licences[0][number]" placeholder="Licence Number"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="licences[0][expiry_date]" id="licences[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[0][state_id]" class="col-md-2 control-label">State</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-lock"></i>
                                <input type="text" class="form-control" name="licences[0][state_id]" id="licences[0][state_id]" placeholder="State"> 
                                
                            </div>
                        </div>
                    </div> 
                    <hr>
                    <h4>Ticket</h4>
                    <div class="form-group">
                        <label for="tickets[0][name]" class="col-md-2 control-label">Ticket</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-ticket"></i>
                                <input type="text" class="form-control" name="tickets[0][name]" id="tickets[0][name]" placeholder="Ticket"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="tickets[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="tickets[0][expiry_date]" id="tickets[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Cards</h4>
                    <div class="form-group">
                        <label for="cards[0][name]" class="col-md-2 control-label">Card</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-credit-card"></i>
                                <input type="text" class="form-control" name="cards[0][name]" id="cards[0][name]" placeholder="Card"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="cards[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="cards[0][expiry_date]" id="cards[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Insurances</h4>
                    <div class="form-group">
                        <label for="insurances[0][name]" class="col-md-2 control-label">Insurance Details</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-paragraph"></i>
                                <textarea name="insurances[0][name]" id="insurances[0][name]" class="form-control" placeholder="Details"></textarea>
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="insurances[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="insurances[0][expiry_date]" id="insurances[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>   
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button type="submit" class="btn green">Submit</button>
                            <a href="{{route('drivers.index')}}" class="btn red">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End: SAMPLE FORM PORTLET -->
    </div>
</div>
@endsection

@push('scripts')
<script type="text/javascript">
    $(function(){
        $('#frmChange').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            rules: {
                name: {
                    required: true,
                },
                address: {
                    required: true
                },
                email: {
                    required:true,
                    email:true,
                    remote: {
                        url: "{{ route('uniqueemail') }}",
                        type: "post",
                        data: {
                            _token: "{{ csrf_token()}}",
                            email: function() {
                                return $( "#email" ).val();
                            }
                        }
                    }
                },
                contact_number:{
                    required:true,
                    number:true,
                    maxlength:15,
                    minlength:8
                },
                dob:{
                    required:true
                }
            },

            messages: {
                name: {
                    required: "@lang('validation.required', ['attribute'=>'full name'])",
                },
                address: {
                    required: "@lang('validation.required', ['attribute'=>'address'])",
                },
                email: {
                    required: "@lang('validation.required', ['attribute'=>'email address'])",
                    email: "@lang('validation.email', ['attribute'=>'email address'])",
                    remote: "@lang('validation.unique', ['attribute'=>'email address'])"
                },
                contact_number:{
                    required: "@lang('validation.required', ['attribute'=>'contact number'])",
                    number: "@lang('validation.numeric', ['attribute'=>'contact number'])",
                    maxlength: "@lang('validation.max.string', ['attribute'=>'contact number', 'max'=>15])",
                    minlength: "@lang("validation.min.string", ['attribute'=>'contact number', 'min'=>8])",
                },
                dob:{
                    required: "@lang('validation.required', ['attribute'=>'date of birth'])",
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit   
                $('.alert-danger', $('.login-form')).show();
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },

            errorPlacement: function (error, element) {
                error.insertAfter(element.closest('.input-icon'));
            },

            submitHandler: function (form) {
                form.submit();
            }
        }); 
        $('.expiry').datepicker({
            orientation:"auto",
            format: "yyyy-mm-dd",    
            startDate: "+0d",
            autoclose: true
        });
        $('#dob').datepicker({
            format: "yyyy-mm-dd",    
            endDate: "+0d",
            autoclose: true
        });
    });
</script>
@endpush