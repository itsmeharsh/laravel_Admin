<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\Role;

class checkRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $routeName = Route::currentRouteName();
        $method = substr($routeName, strrpos($routeName, '.') + 1);
        $routeName = substr($routeName, 0, strrpos($routeName, '.'));
        $method = ($method != '' ? $method : $routeName);
        $permission = 'access';

        $access = ['index', 'listing'];
        $add = ['store', 'create'];
        $update = ['edit', 'update'];
        $view = ['show'];
        $delete = ['destroy'];

        if(in_array($method, $add))
            $permission = 'add';
        elseif(in_array($method, $update))
            $permission = 'edit';
        elseif(in_array($method, $view))
            $permission ='view';
        elseif(in_array($method, $delete))
            $permission = 'delete';

        if(!$request->user()->hasPermission($routeName, $permission)){
            return redirect('/');
        }

        $role = Role::where('route', 'like', $routeName.'%')->first();
        $request->permissions =$role->permissions()->wherePivot('user_id', Auth::id())->get();
        return $next($request);
    }
}
