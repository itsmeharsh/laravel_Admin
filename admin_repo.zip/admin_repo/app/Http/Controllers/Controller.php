<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Models\Role;
use Illuminate\Support\Facades\Route;
use Validator;
use Illuminate\Support\Facades\Auth;



class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function ValidateForm($fields, $rules){
    	$validator = Validator::make($fields, $rules)->validate();
    }

    public function DTFilters($request){
    	$filters = array(
    		'draw' => $request['draw'],
    		'offset' => $request['start'],
    		'limit' => $request['length'],
    		'sort_column' => $request['columns'][$request['order'][0]['column']]['data'],
    		'sort_order' => $request['order'][0]['dir'],
    		'search' => $request['search']['value']

    	);
    	return $filters;
    }
}
