<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Models\Card;
use App\Models\Insurance;
use App\Models\Licence;
use App\Models\Sos;
use App\Models\Ticket;
use Illuminate\Support\Facades\Auth;


class DriverController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('pages.drivers.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.drivers.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $rules = [
            'name'=>'required|max:250',
            'address'=>'required',
            'contact_number'=>'required',
            'email'=>'required|email|unique:users',
            'dob'=>'required|date'
        ];
        $this->validateForm($request->all(), $rules);
        echo '<pre>';print_r($request->all());die;
        $sos = $licences = $tickets = $cards = $insurances = [];
        $driver = User::create([
            'name'=>$request->name,
            'address'=>$request->address,
            'contact_number'=>$request->contact_number,
            'email'=>$request->email,
            'dob'=>$request->dob,
            'user_type' =>'driver'
        ]);

        foreach ($request->sos as $emergency) {
            if($emergency['name'] != '' && $emergency['contact_number'] != ''){
                $sos[] = new Sos($emergency);
            }
        }

        foreach ($request->licences as $licence) {
            if($licence['type'] != '' && $licence['number'] != '' && $licence['expiry_date'] != ''){
                $licences[] = new Licence($licence);
            }
        }

        foreach ($request->tickets as $ticket) {
            if($ticket['name'] != '' && $ticket['expiry_date'] != ''){
                $tickets[] = new Ticket($ticket);
            }
        }

        foreach ($request->cards as $card) {
            if($card['name'] != '' && $card['expiry_date'] != ''){
                $cards[] = new Card($card);
            }
        }

        foreach ($request->insurances as $insurance) {
            if($insurance['name'] != '' && $insurance['expiry_date'] != ''){
                $insurances[] = new Insurance($insurance);
            }
        }

        $driver->sos()->saveMany($sos);
        $driver->licences()->saveMany($licences);
        $driver->tickets()->saveMany($tickets);
        $driver->cards()->saveMany($cards);
        $driver->insurances()->saveMany($insurances);

        flash('Driver added successfully.')->success();
        return redirect()->route('drivers.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try{
            $driver = User::findOrFail($id);
            return view('pages.drivers.show')->with('driver', $driver);

        }catch(ModelNotFoundException $ex){
            abort(404);
        }
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        try{
            $user = User::findOrFail($id);
            return view('pages.drivers.edit')->with('driver', $user);
        }
        catch(ModelNotFoundException $ex){
            abort(404);
        }
    } 

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(!empty($request->action) && $request->action == 'change_status'){
            $content = ['status'=>204, 'message'=>"something went wrong"];
            $driver = User::find($id);
            if($driver){
                $driver->active = $request->value;
                if($driver->save()){
                    $content['status']=200;
                    $content['message'] = "Status updated successfully";
                }
            }
            return response()->json($content);
        }else{
            $rules = [
                'name'=>'required|max:250',
                'address'=>'required',
                'contact_number'=>'required',
                'dob'=>'required|date'
            ];
            $this->validateForm($request->all(), $rules);

            $driver = User::find($id);
            if($driver){
                $driver->name = $request->name;
                $driver->address = $request->address;
                $driver->contact_number = $request->contact_number;
                $driver->dob = $request->dob;
                $driver->save();
                

                foreach ($request->sos as $key=> $emergency) {
                    Sos::updateOrCreate(['id'=>$key, 'user_id'=>$driver->id], $emergency);            
                }

                foreach ($request->licences as $key=> $licence) {
                    Licence::updateOrCreate(['id'=>$key, 'user_id'=>$driver->id], $licence);
                }

                foreach ($request->tickets as $ticket) {
                    Ticket::updateOrCreate(['id'=>$key, 'user_id'=>$driver->id], $ticket);            
                }

                foreach ($request->cards as $card) {
                    Card::updateOrCreate(['id'=>$key, 'user_id'=>$driver->id], $card);            
                }

                foreach ($request->insurances as $insurance) {
                    Insurance::updateOrCreate(['id'=>$key, 'user_id'=>$driver->id], $insurance);           
                }

                flash('Driver updated successfully.')->success();
                return redirect()->route('drivers.index'); 
            }else{
                abort(404);
            }  
        }
        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        User::destroy($id);
        if(request()->ajax()){
            $content = array('status'=>200, 'message'=>"Driver deleted successfully.");
            return response()->json($content);
        }else{
            flash('Driver deleted successfully.')->success();
            return redirect()->route('drivers.index');
        }
        
    }


    public function listing(Request $request){
        extract($this->DTFilters($request->all()));

        $count = User::ofType('driver')->active()->with('sos', 'licences', 'tickets', 'cards', 'insurances');
        if($search != ''){
            $count->where(function($query) use ($search){
                $query->where("name", "like", "%{$search}%")
                ->orWhere("email", "like", "%{$search}%")
                ->orWhere("contact_number", "like", "%{$search}%")
                ->orWhere("dob", "like", "%{$search}%");
            });
        }
        $count = $count->count();

        $records["recordsTotal"] = $count;
        $records["recordsFiltered"] = $count;
        $records['data'] = array();
        $drivers = User::ofType('driver')->offset($offset)->limit($limit)->orderBy($sort_column, $sort_order);
        if($search != ''){
            $drivers->where(function($query) use ($search){
                $query->where("name", "like", "%{$search}%")
                ->orWhere("email", "like", "%{$search}%")
                ->orWhere("contact_number", "like", "%{$search}%")
                ->orWhere("dob", "like", "%{$search}%");
            });
        }
        $drivers = $drivers->get();

        foreach ($drivers as $driver) {
            $params = array(
               'checked'=> ($driver->active ? "checked" : ""),
               'getaction'=>'',
               'class'=>'',
               'id'=> $driver->id
            );
            $records['data'][] = [
                'name'=>$driver->name,
                'email'=>$driver->email,
                'contact_number'=>$driver->contact_number,
                'dob'=>$driver->dob,
                'active'=>view('shared.switch', compact('params'))->render(),
                'action'=>view('shared.actions')->with('id', $driver->id)->render()
            ];
        }

        return $records;
    }
}
