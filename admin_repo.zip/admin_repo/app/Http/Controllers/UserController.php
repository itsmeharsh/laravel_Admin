<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\User;

class UserController extends Controller
{
    
	public function showChangePassword(){
		return view('pages.change_password');
	}
    public function changePassword(Request $request){
    	$rules = [
    		'current_password'=>'required|min:6',
    		'password'=>'required|min:6|confirmed',
    		'password_confirmation'=>'required|min:6'
    	];
    	$this->validateForm($request->all(), $rules);

    	if(Hash::check($request->current_password, Auth::user()->password)){
    		$user = Auth::user();
    		$user->password = Hash::make($request->password);
    		$user->save();

    	}else{

    	}
    	return redirect()->route('changepass');
    }

    public function checkUniqueEmail(Request $request){
        $user = User::where('email', $request->email)->first();
        if($user)
            return "false";
        else
            return "true";
    }
}
