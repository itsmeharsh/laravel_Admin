<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\Role;
use App\Models\Permission;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'contact_number', 'dob', 'sos', 'address', 'user_type'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Scope a query to only include users of a given type.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param mixed $type
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfType($query, $type)
    {
        return $query->where('user_type', $type);
    }

    /**
     * Scope a query to only include active users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('active', 1);
    }
    
    public function hasPermission($routeName, $permission){
        $permissionId = Permission::where('constant', '=', $permission)->first()->id;
        
        $isPermitted = Role::where('route', 'like', $routeName.'%')->whereHas('permissions', function($query) use ($permissionId){
            $query->where('permission_id', '=', $permissionId);
        })->first();
        if(!$isPermitted)
            return false;
        else
            return true;
        
    }

    public function sos(){
        return $this->hasMany('App\Models\Sos');
    }

    public function licences(){
        return $this->hasMany('App\Models\Licence');
    }

    public function cards(){
        return $this->hasMany('App\Models\Card');
    }

    public function insurances(){
        return $this->hasMany('App\Models\Insurance');
    }

    public function leaves(){
        return $this->hasMany('App\Models\Leave');
    }

    public function tickets(){
        return $this->hasMany('App\Models\Ticket');
    }

    public function trucks(){
        return $this->hasMany('App\Models\Truck');
    }
    
    public function roles(){
        return $this->belongsToMany('App\Models\Role')->withPivot('permission_id');
    }
}
