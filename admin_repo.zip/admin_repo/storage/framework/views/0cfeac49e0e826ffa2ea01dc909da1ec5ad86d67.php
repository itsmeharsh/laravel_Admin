<?php if(in_array('edit', $permissions)): ?>
	<td>
		<input type="checkbox" <?php echo e($params["checked"]); ?> data-id="<?php echo e($params['id']); ?>" data-url="<?php echo e(route($routeName.'.update', $params['id'])); ?>" class="make-switch <?php echo e(!empty($params['class']) ? $params['class'] : 'status-switch'); ?>" data-getaction="<?php echo e((!empty($params['getaction']) ? $params['getaction'] : '')); ?>" data-on-label="<i class=\'fa fa-check\'></i>" data-off-label="<i class=\'fa fa-times\' ></i>" >
	</td>
<?php endif; ?>
