<?php $__env->startSection('content'); ?>
 <div class="row ">
    <div class="col-md-12">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-social-dribbble font-green-soft"></i>
                    <span class="caption-subject font-green bold uppercase">View Driver</span>
                </div>
                
            </div>
            <div class="portlet-body">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#personal" data-toggle="tab"> Personal </a>
                    </li>
                    <li>
                        <a href="#sos" data-toggle="tab"> SOS </a>
                    </li>
                    <li>
                        <a href="#licence" data-toggle="tab"> Licences </a>
                    </li>
                    <li>
                        <a href="#tickets" data-toggle="tab"> Tickets </a>
                    </li>
                    <li>
                        <a href="#cards" data-toggle="tab"> Cards </a>
                    </li>
                    <li>
                        <a href="#insurance" data-toggle="tab"> Insurances </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade active in" id="personal">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group clearfix">
                                    <label class="control-label col-md-3">Full name: </label>
                                    <div class="col-md-9"><?php echo e($driver->name); ?></div>
                                </div>
                                <div class="form-group clearfix">
                                    <label class="control-label col-md-3">Address: </label>
                                    <div class="col-md-9"><?php echo e($driver->address); ?></div>
                                </div>
                                <div class="form-group clearfix">
                                    <label class="control-label col-md-3">Contact number: </label>
                                    <div class="col-md-9"><?php echo e($driver->contact_number); ?></div>
                                </div>
                                <div class="form-group clearfix">
                                    <label class="control-label col-md-3">Date of birth: </label>
                                    <div class="col-md-9"><?php echo e(date('M d, Y', strtotime($driver->dob))); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="sos">
                        <div class="row">
                            <div class="col-md-10">
                                <?php $__currentLoopData = $driver->sos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Name: </label>
                                        <div class="col-md-9"><?php echo e($sos->name); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Contact number: </label>
                                        <div class="col-md-9"><?php echo e($sos->contact_number); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Relation: </label>
                                        <div class="col-md-9"><?php echo e($sos->relation); ?></div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="licence">
                        <div class="row">
                            <div class="col-md-10">
                                <?php $__currentLoopData = $driver->licences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Licence type: </label>
                                        <div class="col-md-9"><?php echo e($licence->type); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Licence number: </label>
                                        <div class="col-md-9"><?php echo e($licence->number); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Expiry date: </label>
                                        <div class="col-md-9"><?php echo e(date('M d, Y', strtotime($licence->expiry_date))); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">State: </label>
                                        <div class="col-md-9"><?php echo e($licence->state_id); ?></div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tickets">
                        <div class="row">
                            <div class="col-md-10">
                                <?php $__currentLoopData = $driver->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Ticket: </label>
                                        <div class="col-md-9"><?php echo e($ticket->name); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Expiry date: </label>
                                        <div class="col-md-9"><?php echo e(date('M d, Y', strtotime($ticket->expiry_date))); ?></div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="cards">
                        <div class="row">
                            <div class="col-md-10">
                                <?php $__currentLoopData = $driver->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Card: </label>
                                        <div class="col-md-9"><?php echo e($card->name); ?></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Expiry date: </label>
                                        <div class="col-md-9"><?php echo e(date('M d, Y', strtotime($card->expiry_date))); ?></div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="insurance">
                        <div class="row">
                            <div class="col-md-10">
                                <?php $__currentLoopData = $driver->insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Details: </label>
                                        <div class="col-md-9"><p><?php echo e($insurance->name); ?></p></div>
                                    </div>
                                    <div class="form-group clearfix">
                                        <label class="control-label col-md-3">Expiry date: </label>
                                        <div class="col-md-9"><?php echo e(date('M d, Y', strtotime($insurance->expiry_date))); ?></div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix margin-bottom-20"> </div>
                <div class="form-group">
                    <div class="col-md-offset-2 col-md-10">
                        <a href="<?php echo e(route('drivers.index')); ?>" class="btn red">Back</a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- End: SAMPLE FORM PORTLET -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>