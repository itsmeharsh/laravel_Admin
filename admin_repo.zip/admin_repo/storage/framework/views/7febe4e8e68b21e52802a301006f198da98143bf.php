<?php $__currentLoopData = (array) session('flash_notification'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($message['overlay']): ?>
        <?php echo $__env->make('flash::modal', [
            'modalClass' => 'flash-modal',
            'title'      => $message['title'],
            'body'       => $message['message']
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        <?php $__env->startPush('scripts'); ?>
            <script type="text/javascript">
                $(function(){                    
                    toastr['<?php echo e($message['level']); ?>']("<?php echo $message['message']; ?>");
                });
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e(session()->forget('flash_notification')); ?>

