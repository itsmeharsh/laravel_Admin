<?php if(in_array('view', $permissions) || in_array('edit', $permissions) || in_array('delete', $permissions)): ?>
	<?php if(in_array('view', $permissions)): ?>
	<a href="<?php echo e(route($routeName.'.show', $id)); ?>" title="View" class="btn btn-success btn-xs">View</a>
	<?php endif; ?>
	<?php if(in_array('edit', $permissions)): ?>
		<a href="<?php echo e(route($routeName.'.edit', $id)); ?>" title="Edit" class="btn btn-warning btn-xs">Edit</a>
	<?php endif; ?>
	<?php if(in_array('delete', $permissions)): ?>
		<a title="Delete" href="<?php echo e(route($routeName.'.destroy', $id)); ?>" class="btn btn-danger btn-xs act-delete">Delete</a>
	<?php endif; ?>
<?php endif; ?>




