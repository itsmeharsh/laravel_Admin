<?php $__env->startSection('content'); ?>
 <div class="row ">
    <div class="col-md-12">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-user font-green"></i>
                    <span class="caption-subject font-green bold uppercase">Add Driver</span>
                </div>
            </div>
            <div class="portlet-body">
                <form class="form-horizontal" id="frmChange" role="form" method="POST" action="<?php echo e(route('drivers.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <h4>Personal Details</h4>
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-2 control-label"><?php echo $mend_sign; ?>Full Name</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-user"></i>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Name"> 
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-2 control-label"><?php echo $mend_sign; ?>Address</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-map-pin"></i>
                                <textarea name="address" id="address" class="form-control" placeholder="Address"></textarea>
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('contact_number') ? ' has-error' : ''); ?>">
                        <label for="contact_number" class="col-md-2 control-label"><?php echo $mend_sign; ?>Contact Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-phone"></i>
                                <input type="text" class="form-control" name="contact_number" id="contact_number" placeholder="Contact number"> 
                                <?php if($errors->has('contact_number')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('contact_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-2 control-label"><?php echo $mend_sign; ?>E-mail address</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-envelope"></i>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Email address"> 
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
                        <label for="dob" class="col-md-2 control-label"><?php echo $mend_sign; ?>Date of birth</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control" name="dob" id="dob" placeholder="Date of birth" readonly="readonly"> 
                                <?php if($errors->has('dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Emergency Contact</h4>
                    <div class="form-group">
                        <label for="sos[][name]" class="col-md-2 control-label">Name</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-user"></i>
                                <input type="text" class="form-control" name="sos[][name]" id="sos[][name]" placeholder="Name"> 
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="sos[][contact_number]" class="col-md-2 control-label">Contact Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-phone"></i>
                                <input type="text" class="form-control" name="sos[][contact_number]" id="sos[][contact_number]" placeholder="Contact Number"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="sos[][relation]" class="col-md-2 control-label">Relation</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-sitemap"></i>
                                <input type="text" class="form-control" name="sos[][relation]" id="sos[][relation]" placeholder="Relation"> 
                                
                            </div>
                        </div>
                    </div>  
                    <hr>
                    <h4>License</h4>
                    <div class="form-group">
                        <label for="licences[][type]" class="col-md-2 control-label">Licence type</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-cubes"></i>
                                <input type="text" class="form-control" name="licences[][type]" id="licences[][type]" placeholder="Licence Type"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[][number]" class="col-md-2 control-label">Licence Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-credit-card"></i>
                                <input type="text" class="form-control" name="licences[][number]" id="licences[][number]" placeholder="Licence Number"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="licences[][expiry_date]" id="licences[][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="licences[][state_id]" class="col-md-2 control-label">State</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-lock"></i>
                                <input type="text" class="form-control" name="licences[][state_id]" id="licences[][state_id]" placeholder="State"> 
                                
                            </div>
                        </div>
                    </div> 
                    <hr>
                    <h4>Ticket</h4>
                    <div class="form-group">
                        <label for="tickets[][name]" class="col-md-2 control-label">Ticket</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-ticket"></i>
                                <input type="text" class="form-control" name="tickets[][name]" id="tickets[][name]" placeholder="Ticket"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="tickets[][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="tickets[][expiry_date]" id="tickets[][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Cards</h4>
                    <div class="form-group">
                        <label for="cards[][name]" class="col-md-2 control-label">Card</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-credit-card"></i>
                                <input type="text" class="form-control" name="cards[][name]" id="cards[][name]" placeholder="Card"> 
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="cards[][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="cards[][expiry_date]" id="cards[][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Insurances</h4>
                    <div class="form-group">
                        <label for="insurances[][name]" class="col-md-2 control-label">Insurance Details</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-paragraph"></i>
                                <textarea name="insurances[][name]" id="insurances[][name]" class="form-control" placeholder="Details"></textarea>
                                
                            </div>
                        </div>
                    </div>  
                    <div class="form-group">
                        <label for="insurances[][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control expiry" name="insurances[][expiry_date]" id="insurances[][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                
                            </div>
                        </div>
                    </div>   
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button type="submit" class="btn green">Submit</button>
                            <a href="<?php echo e(route('drivers.index')); ?>" class="btn red">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End: SAMPLE FORM PORTLET -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#frmChange').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            rules: {
                name: {
                    required: true,
                },
                address: {
                    required: true
                },
                email: {
                    required:true,
                    email:true,
                    remote: {
                        url: "<?php echo e(route('uniqueemail')); ?>",
                        type: "post",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            email: function() {
                                return $( "#email" ).val();
                            }
                        }
                    }
                },
                contact_number:{
                    required:true,
                    number:true,
                    maxlength:15,
                    minlength:8
                },
                dob:{
                    required:true
                }
            },

            messages: {
                name: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'full name']); ?>",
                },
                address: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'address']); ?>",
                },
                email: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'email address']); ?>",
                    email: "<?php echo app('translator')->getFromJson('validation.email', ['attribute'=>'email address']); ?>",
                    remote: "<?php echo app('translator')->getFromJson('validation.unique', ['attribute'=>'email address']); ?>"
                },
                contact_number:{
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'contact number']); ?>",
                    number: "<?php echo app('translator')->getFromJson('validation.numeric', ['attribute'=>'contact number']); ?>",
                    maxlength: "<?php echo app('translator')->getFromJson('validation.max.string', ['attribute'=>'contact number', 'max'=>15]); ?>",
                    minlength: "<?php echo app('translator')->getFromJson("validation.min.string", ['attribute'=>'contact number', 'min'=>8]); ?>",
                },
                dob:{
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'date of birth']); ?>",
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit   
                $('.alert-danger', $('.login-form')).show();
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },

            errorPlacement: function (error, element) {
                error.insertAfter(element.closest('.input-icon'));
            },

            submitHandler: function (form) {
                form.submit();
            }
        }); 
        $('.expiry').datepicker({
            orientation:"auto",
            format: "yyyy-mm-dd",    
            startDate: "+0d",
            autoclose: true
        });
        $('#dob').datepicker({
            format: "yyyy-mm-dd",    
            endDate: "+0d",
            autoclose: true
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>