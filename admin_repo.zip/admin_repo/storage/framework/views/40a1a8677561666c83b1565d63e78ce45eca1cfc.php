<div class="page-footer">
    <div class="page-footer-inner"> <?php echo e(date('Y')); ?> &copy; <?php echo e(config('app.name')); ?>.
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>