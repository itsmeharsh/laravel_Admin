<?php $__env->startSection('content'); ?>
 <div class="row ">
    <div class="col-md-12">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-lock font-dark"></i>
                    <span class="caption-subject font-dark bold uppercase">Change Password</span>
                </div>
                
            </div>
            <div class="portlet-body">
                <form class="form-horizontal" id="frmChange" role="form" method="POST" action="<?php echo e(route('changepass')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group<?php echo e($errors->has('current_password') ? ' has-error' : ''); ?>">
                        <label for="current_password" class="col-md-2 control-label">Current Password</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-lock"></i>
                                <input type="password" class="form-control" name="current_password" id="current_password" placeholder="Current Password"> 
                                <?php if($errors->has('current_password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('current_password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-2 control-label">New Password</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-lock"></i>
                                <input type="password" class="form-control" name="password" id="password" placeholder="New Password"> 
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        <label for="password_confirmation" class="col-md-2 control-label">Confirm Password</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-lock"></i>
                                <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password"> 
                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button type="submit" class="btn green">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End: SAMPLE FORM PORTLET -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#frmChansge').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            rules: {
                current_password: {
                    required: true,
                    minlength:6
                },
                password: {
                    required: true,
                    minlength:6
                },
                password_confirmation: {
                    required:true,
                    minlength:6,
                    equalTo: '#password'
                }
            },

            messages: {
                current_password: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'current password']); ?>",
                    minlength: "<?php echo app('translator')->getFromJson('validation.min.string', ['attribute'=>'current password', 'min'=>6]); ?>"
                },
                password: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'password']); ?>",
                    minlength: "<?php echo app('translator')->getFromJson('validation.min.string', ['attribute'=>'password', 'min'=>6]); ?>"
                },
                password_confirmation: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'confirm password']); ?>",
                    minlength: "<?php echo app('translator')->getFromJson('validation.min.string', ['attribute'=>'confirm password', 'min'=>6]); ?>",
                    equalTo: "<?php echo app('translator')->getFromJson('validation.confirmed', ['attribute'=>'password']); ?>"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit   
                $('.alert-danger', $('.login-form')).show();
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },

            errorPlacement: function (error, element) {
                error.insertAfter(element.closest('.input-icon'));
            },

            submitHandler: function (form) {
                form.submit();
            }
        }); 
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>