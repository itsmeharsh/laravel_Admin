<?php $__env->startSection('content'); ?>
 <div class="row ">
    <div class="col-md-12">
        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-user font-green"></i>
                    <span class="caption-subject font-green bold uppercase">Update Driver</span>
                </div>
            </div>
            <div class="portlet-body">
                <form class="form-horizontal" id="frmChange" role="form"  action="<?php echo e(route('drivers.update', $driver->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <h4>Personal Details</h4>
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-2 control-label"><?php echo $mend_sign; ?>Full Name</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-user"></i>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo e($driver->name); ?>"> 
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-2 control-label"><?php echo $mend_sign; ?>Address</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-map-pin"></i>
                                <textarea name="address" id="address" class="form-control" placeholder="Address"><?php echo e($driver->address); ?></textarea>
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('contact_number') ? ' has-error' : ''); ?>">
                        <label for="contact_number" class="col-md-2 control-label"><?php echo $mend_sign; ?>Contact Number</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-phone"></i>
                                <input type="text" class="form-control" name="contact_number" id="contact_number" placeholder="Contact number" value="<?php echo e($driver->contact_number); ?>"> 
                                <?php if($errors->has('contact_number')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('contact_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
                        <label for="dob" class="col-md-2 control-label"><?php echo $mend_sign; ?>Date of birth</label>
                        <div class="col-md-4">
                            <div class="input-icon">
                                <i class="fa fa-calendar"></i>
                                <input type="text" class="form-control" name="dob" id="dob" placeholder="Date of birth" readonly="readonly" value="<?php echo e($driver->dob); ?>"> 
                                <?php if($errors->has('dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h4>Emergency Contact</h4>
                    <?php if(!count($driver->sos)): ?>
                        <div class="form-group">
                            <label for="sos[0][name]" class="col-md-2 control-label">Name</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-user"></i>
                                    <input type="text" class="form-control" name="sos[0][name]" id="sos[0][name]" placeholder="Name"> 
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="sos[0][contact_number]" class="col-md-2 control-label">Contact Number</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-phone"></i>
                                    <input type="text" class="form-control" name="sos[0][contact_number]" id="sos[0][contact_number]" placeholder="Contact Number"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="sos[0][relation]" class="col-md-2 control-label">Relation</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-sitemap"></i>
                                    <input type="text" class="form-control" name="sos[0][relation]" id="sos[0][relation]" placeholder="Relation"> 
                                    
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $driver->sos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <label for="sos[<?php echo e($sos->id); ?>][name]" class="col-md-2 control-label">Name</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-user"></i>
                                        <input type="text" class="form-control" name="sos[<?php echo e($sos->id); ?>][name]" id="sos[<?php echo e($sos->id); ?>][name]" placeholder="Name" value="<?php echo e($sos->name); ?>"> 
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="sos[<?php echo e($sos->id); ?>][contact_number]" class="col-md-2 control-label">Contact Number</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-phone"></i>
                                        <input type="text" class="form-control" name="sos[<?php echo e($sos->id); ?>][contact_number]" id="sos[<?php echo e($sos->id); ?>][contact_number]" placeholder="Contact Number" value="<?php echo e($sos->contact_number); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="sos[<?php echo e($sos->id); ?>][relation]" class="col-md-2 control-label">Relation</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-sitemap"></i>
                                        <input type="text" class="form-control" name="sos[<?php echo e($sos->id); ?>][relation]" id="sos[<?php echo e($sos->id); ?>][relation]" placeholder="Relation" value="<?php echo e($sos->relation); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <hr>
                    <h4>License</h4>
                    <?php if(!count($driver->licences)): ?>
                        <div class="form-group">
                            <label for="licences[0][type]" class="col-md-2 control-label">Licence type</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-cubes"></i>
                                    <input type="text" class="form-control" name="licences[0][type]" id="licences[0][type]" placeholder="Licence Type"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="licences[0][number]" class="col-md-2 control-label">Licence Number</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-credit-card"></i>
                                    <input type="text" class="form-control" name="licences[0][number]" id="licences[0][number]" placeholder="Licence Number"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="licences[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-calendar"></i>
                                    <input type="text" class="form-control expiry" name="licences[0][expiry_date]" id="licences[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="licences[0][state_id]" class="col-md-2 control-label">State</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-lock"></i>
                                    <input type="text" class="form-control" name="licences[0][state_id]" id="licences[0][state_id]" placeholder="State"> 
                                    
                                </div>
                            </div>
                        </div> 
                    <?php else: ?>
                        <?php $__currentLoopData = $driver->licences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <label for="licences[<?php echo e($licence->id); ?>][type]" class="col-md-2 control-label">Licence type</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-cubes"></i>
                                        <input type="text" class="form-control" name="licences[<?php echo e($licence->id); ?>][type]" id="licences[<?php echo e($licence->id); ?>][type]" placeholder="Licence Type" value="<?php echo e($licence->type); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="licences[<?php echo e($licence->id); ?>][number]" class="col-md-2 control-label">Licence Number</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-credit-card"></i>
                                        <input type="text" class="form-control" name="licences[<?php echo e($licence->id); ?>][number]" id="licences[<?php echo e($licence->id); ?>][number]" placeholder="Licence Number" value="<?php echo e($licence->number); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="licences[<?php echo e($licence->id); ?>][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-calendar"></i>
                                        <input type="text" class="form-control expiry" name="licences[<?php echo e($licence->id); ?>][expiry_date]" id="licences[<?php echo e($licence->id); ?>][expiry_date]" placeholder="Expiry date" readonly="readonly" value="<?php echo e($licence->expiry_date); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="licences[<?php echo e($licence->id); ?>][state_id]" class="col-md-2 control-label">State</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-lock"></i>
                                        <input type="text" class="form-control" name="licences[<?php echo e($licence->id); ?>][state_id]" id="licences[<?php echo e($licence->id); ?>][state_id]" placeholder="State" value="<?php echo e($licence->state_id); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                     
                    <hr>
                    <h4>Ticket</h4>
                    <?php if(!count($driver->tickets)): ?>
                        <div class="form-group">
                            <label for="tickets[0][name]" class="col-md-2 control-label">Ticket</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-ticket"></i>
                                    <input type="text" class="form-control" name="tickets[0][name]" id="tickets[0][name]" placeholder="Ticket"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="tickets[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-calendar"></i>
                                    <input type="text" class="form-control expiry" name="tickets[0][expiry_date]" id="tickets[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                    
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $driver->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <label for="tickets[<?php echo e($ticket->id); ?>][name]" class="col-md-2 control-label">Ticket</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-ticket"></i>
                                        <input type="text" class="form-control" name="tickets[<?php echo e($ticket->id); ?>][name]" id="tickets[<?php echo e($ticket->id); ?>][name]" placeholder="Ticket" value="<?php echo e($ticket->name); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="tickets[<?php echo e($ticket->id); ?>][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-calendar"></i>
                                        <input type="text" class="form-control expiry" name="tickets[<?php echo e($ticket->id); ?>][expiry_date]" id="tickets[0][expiry_date]" placeholder="Expiry date" readonly="readonly" value="<?php echo e($ticket->expiry_date); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>                    
                    <hr>
                    <h4>Cards</h4>
                    <?php if(!count($driver->cards)): ?>
                        <div class="form-group">
                            <label for="cards[0][name]" class="col-md-2 control-label">Card</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-credit-card"></i>
                                    <input type="text" class="form-control" name="cards[0][name]" id="cards[0][name]" placeholder="Card"> 
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="cards[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-calendar"></i>
                                    <input type="text" class="form-control expiry" name="cards[0][expiry_date]" id="cards[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                    
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $driver->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <label for="cards[<?php echo e($card->id); ?>][name]" class="col-md-2 control-label">Card</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-credit-card"></i>
                                        <input type="text" class="form-control" name="cards[<?php echo e($card->id); ?>][name]" id="cards[<?php echo e($card->id); ?>][name]" placeholder="Card" value="<?php echo e($card->name); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="cards[<?php echo e($card->id); ?>][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-calendar"></i>
                                        <input type="text" class="form-control expiry" name="cards[<?php echo e($card->id); ?>][expiry_date]" id="cards[<?php echo e($card->id); ?>][expiry_date]" placeholder="Expiry date" readonly="readonly" value="<?php echo e($card->expiry_date); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    <hr>
                    <h4>Insurances</h4>
                    <?php if(!count($driver->insurances)): ?>
                        <div class="form-group">
                            <label for="insurances[0][name]" class="col-md-2 control-label">Insurance Details</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-paragraph"></i>
                                    <textarea name="insurances[0][name]" id="insurances[0][name]" class="form-control" placeholder="Details"></textarea>
                                    
                                </div>
                            </div>
                        </div>  
                        <div class="form-group">
                            <label for="insurances[0][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                            <div class="col-md-4">
                                <div class="input-icon">
                                    <i class="fa fa-calendar"></i>
                                    <input type="text" class="form-control expiry" name="insurances[0][expiry_date]" id="insurances[0][expiry_date]" placeholder="Expiry date" readonly="readonly"> 
                                    
                                </div>
                            </div>
                        </div>   
                    <?php else: ?>
                        <?php $__currentLoopData = $driver->insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <label for="insurances[<?php echo e($insurance->id); ?>][name]" class="col-md-2 control-label">Insurance Details</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-paragraph"></i>
                                        <textarea name="insurances[<?php echo e($insurance->id); ?>][name]" id="insurances[<?php echo e($insurance->id); ?>][name]" class="form-control" placeholder="Details"><?php echo e($insurance->name); ?></textarea>
                                        
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="insurances[<?php echo e($insurance->id); ?>][expiry_date]" class="col-md-2 control-label">Expiry date</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="fa fa-calendar"></i>
                                        <input type="text" class="form-control expiry" name="insurances[<?php echo e($insurance->id); ?>][expiry_date]" id="insurances[<?php echo e($insurance->id); ?>][expiry_date]" placeholder="Expiry date" readonly="readonly" value="<?php echo e($insurance->expiry_date); ?>"> 
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>                       
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button type="submit" class="btn green">Submit</button>
                            <a href="<?php echo e(route('drivers.index')); ?>" class="btn red">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End: SAMPLE FORM PORTLET -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#frmChange').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            rules: {
                name: {
                    required: true
                },
                address: {
                    required: true
                },
                contact_number:{
                    required:true,
                    number: true,
                    maxlength:15,
                    minlength:8
                },
                dob:{
                    required:true
                }
            },

            messages: {
                name: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'full name']); ?>",
                },
                address: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'address']); ?>",
                },
                email: {
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'email address']); ?>",
                    email: "<?php echo app('translator')->getFromJson('validation.email', ['attribute'=>'email address']); ?>"
                },
                contact_number:{
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'contact number']); ?>",
                    number: "<?php echo app('translator')->getFromJson('validation.numeric', ['attribute'=>'contact number']); ?>",
                    maxlength: "<?php echo app('translator')->getFromJson('validation.max.string', ['attribute'=>'contact number', 'max'=>15]); ?>",
                    minlength: "<?php echo app('translator')->getFromJson("validation.min.string", ['attribute'=>'contact number', 'min'=>8]); ?>",

                },
                dob:{
                    required: "<?php echo app('translator')->getFromJson('validation.required', ['attribute'=>'date of birth']); ?>",
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit   
                $('.alert-danger', $('.login-form')).show();
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },

            errorPlacement: function (error, element) {
                error.insertAfter(element.closest('.input-icon'));
            },

            submitHandler: function (form) {
                form.submit();
            }
        }); 
        $('.expiry').datepicker({
            format: "yyyy-mm-dd",    
            startDate: "+0d",
            autoclose: true
        });
        $('#dob').datepicker({
            format: "yyyy-mm-dd",    
            endDate: "+0d",
            autoclose: true
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>