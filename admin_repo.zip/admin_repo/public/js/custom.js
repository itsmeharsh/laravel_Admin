$(function () {
    /* Code to set sidebar li active */
    $('.page-sidebar-menu li').filter(function () {
        return $(this).hasClass('active');
    }).parent('ul').parent('li').addClass('active open');
    
    /**
     * Delete record from database
     * @param  
     * @return {[type]}      [description]
     */
    $(document).on('click', '.act-delete', function(e){
    	e.preventDefault();
    	var action = $(this).attr('href');
    	bootbox.confirm('Are you sure! you want to delete this record?', function(res){
    		if(res){
		    	$.ajax({
                    url: action,
                    type: 'DELETE',
                    dataType: 'json',
                    beforeSend:addOverlay,
                    data: {
                        _token: $('meta[name="csrf_token"]').attr('content')
                    },
                    success:function(r){
                        sType = getStatusText(r.status);
                        sText = r.message;
                        showMessage(sType,sText);
                        if (typeof oTable.draw !== "undefined")
                        { 
                            oTable.draw();
                        }
                        else if (typeof oTable.fnDraw !== "undefined")
                        { 
                            oTable.fnDraw();
                        }
                    },
                    complete:removeOverlay
                });
    		}
    	});
    	
    });
    $(document).on('switchChange.bootstrapSwitch','.status-switch', function(event, state) {
        var $this = $(this);
        var customAct = typeof $(this).data('getaction') != 'undefined' ? $(this).data('getaction') : '';
        var val = state ? 1 : 0;
        var url = $(this).data('url');
        var action =  customAct != '' ? customAct : 'change_status'; 
        
        $.ajax({
            url: url,
            type: 'PUT',
            dataType: 'json',
            beforeSend:addOverlay,
            data: {
                _token: $('meta[name="csrf_token"]').attr('content'),
                action:action, 
                value:val
            },
            success:function(r){
                sType = getStatusText(r.status);
                sText = r.message;
                showMessage(sType,sText);
                if(r.status != 200){
                    $this.prop("checked", !$this.prop("checked"));
                }
                removeOverlay();
            },
            complete:removeOverlay
        });
    });
});
function getStatusText(code)
{
    sText = "";
    if(code !== undefined)
    {
        switch(code)
        {
            case 200:{ sText = 'Success';break;}
            case 404:{ sText = 'Error';break;}
            case 403:{ sText = 'Error';break;}
            case 500:{ sText = 'Error';break;}
            default:{sText = 'Error';}
            
        }
    }
    return sText;
}

function showMessage(sType,sText){
    toastr[sType.toLowerCase()](sText);
}
function addOverlay(){$('<div id="overlayDocument"><img src="images/loading.gif" /></div>').appendTo(document.body);}
function removeOverlay(){$('#overlayDocument').remove();}