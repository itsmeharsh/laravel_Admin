<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('dashboard.index');

Auth::routes();
Route::group(['middleware' => ['auth', 'permission']], function () {
	/* Drivers */
	Route::get('drivers/listing', 'DriverController@listing')->name('drivers.listing');
	Route::resource('drivers', 'DriverController');
	
	/* Mechanics */
	Route::resource('mechanics', 'MechanicController');
	Route::resource('contractors', 'ContractorController');
});

Route::group(['middleware' => 'auth'], function () {
	Route::get('change-password', 'UserController@showChangePassword')->name('showChangePass');
	Route::post('change-password', 'UserController@changePassword')->name('changepass');
	Route::post('unique-email', 'UserController@checkUniqueEmail')->name('uniqueemail');

});

